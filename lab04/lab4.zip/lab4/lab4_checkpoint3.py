from sample_functions import sing_verse
from sample_functions import simple_postage


input_a=input("enter nmber between 1 and 99:")


sing_verse(input_a)


input_b=input("wight of the letter:")

return_b=simple_postage(input_b)
print return_b
