amount=67

q=amount/25
leftafterq=(amount-(q*25))

dime=leftafterq/10
afterdime=(leftafterq-(dime*10))

nickles=afterdime/5
afternick=(afterdime-(nickles*5))

pennies=afternick

print "Quarters: ", q
print "Dimes: ", dime
print "Nickels ", nickles
print "Pennies ", pennies

