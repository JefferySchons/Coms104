import math

y=2.7
x=round(y)
#z=ceil(y)
print x
print int(y)

print math.sqrt(25)

print "Hello world"
print "hello", "world"
print"hello"+"world"
print "hello"
print"world"
print"hello",
print"world"
