print "Tile Limited"

length=input("Length of the rectangle (in feet):")
width=input("Width of the rectangle (in feet):")
price_sq_ft=input("Price of a square foot of tile ($):")

area=length*width
price=area*price_sq_ft

print "Area of the rectangle (int square feet):",area
print "Total price of the tiles needed ($):", price
