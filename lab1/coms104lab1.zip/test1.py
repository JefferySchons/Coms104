#this in my fist pythn scipt
print 2+3
print "Hello, world!"
