#this in my fist pythn scipt
2+3
print "Hello, world!"
